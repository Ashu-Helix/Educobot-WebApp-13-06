// const GAME_CONSTANT = {
//   images: {
//     whereAmIBg: "whereAmIBg",
//     speechBubble:'speechBubble'
//   },
//   spritesImages: {
//     robSpritesheet_1: "robSpritesheet_1",
//     robSpritesheet_2: "robSpritesheet_2",
//     robSpritesheet_3: "robSpritesheet_3",
//     robSpritesheet_4: "robSpritesheet_4",
//     copSpritesheet: "copSpritesheet",
//   }
// };
// const INCORRECT_MESSAGE = 'You have entered the incorrect coordinates for the robber.';
// const CORRECT_MESSAGE = 'You have entered the correct coordinates for the robber ';
// const CAUGHT_ALL = 'Congratulations!!! You have caught all the robber.';