// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;
// const totalRob = 4;

// const spriteElement = {
//     robSpritesheet_1: { x: 200, stayAt: 0, frameWidth: 403, frameHeight: 363, frameFrom: 0, frameTo: 10, frameRate: 6 },
//     robSpritesheet_2: { x: 650, stayAt: 0, frameWidth: 473, frameHeight: 378, frameFrom: 0, frameTo: 10, frameRate: 6 },
//     robSpritesheet_3: { x: 1280, stayAt: 0, frameWidth: 461, frameHeight: 386, frameFrom: 0, frameTo: 10, frameRate: 6 },
//     robSpritesheet_4: { x: 1725, stayAt: 0, frameWidth: 392, frameHeight: 406, frameFrom: 0, frameTo: 10, frameRate: 6 },
//     copSpritesheet: { x: 920, y: 760, stayAt: 0, happyAt: 2, sadAt: 1, frameWidth: 427, frameHeight: 1500, frameFrom: 0, frameTo: 2, frameRate: 6, scale: 0.63 }
// }

// const hitPoints = [
//     { x1: 1, y1: 722, x2: 354, y2: 1071, name: 'robSpritesheet_1' },
//     { x1: 434, y1: 717, x2: 792, y2: 1071, name: 'robSpritesheet_2' },
//     { x1: 1071, y1: 704, x2: 1460, y2: 1071, name: 'robSpritesheet_3' },
//     { x1: 1574, y1: 704, x2: 1902, y2: 1071, name: 'robSpritesheet_4' }
// ]