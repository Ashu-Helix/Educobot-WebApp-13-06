// const GAME_CONSTANT = {
//   images: {
//     healthNotiferBg: "healthNotiferBg",
//     speechBubble: "speechBubble"
//   },
//   spritesImages: {
//     girl: "girl",
//     robot: "robot",
//     numbers: "numbers",
//   }
// };
// const ERROR_MESSAGE = 'Oops! You have not completelly the exactlly 50 steps.';
// const CORRECT_MESSAGE = 'Congratulation! You have completed the exercise now, take a rest.';