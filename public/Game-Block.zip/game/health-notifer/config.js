// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;
// const correctCounts = 50;
// const magicElement = {
//     girl: { x: 600, y: 550, stay: 5, frameWidth: 760, frameHeight: 1358, frameFrom: 0, frameTo: 5, frameRate: 10, repeat: 0 },
//     robot: { x: 1260, y: 550, stay: 5, frameWidth: 516, frameHeight: 817, frameFrom: 0, frameTo: 5, frameRate: 10, repeat: 0 },
//     numbers: { x: 1260, y: 565, stay: 99, frameWidth: 132, frameHeight: 86, frameFrom: 0, frameTo: 100, frameRate: 5, repeat: 0 }
// }