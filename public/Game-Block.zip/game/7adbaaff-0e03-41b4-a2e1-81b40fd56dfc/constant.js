/* Developed by Marvsoft LLP */

const GAME_CONSTANT = {
  images: {
    healthIsWealthBG: "healthIsWealthBG"
  },
  spritesImages: {
    girlSprite: "girlSprite"
  }
};
const INCORRECT_MESSAGE = 'You have entered incorrect number of jumps.';
const CORRECT_MESSAGE = 'You have entered correct number of jumps.';
