/* Developed by Marvsoft LLP */

let _gameThis = null;
const baseURL = "assets";
const gameWidth = 1920;
const gameHeight = 1080;
const gameScale = 1;

const correctCounts = 50;
const magicElement = {
    girlSprite: {
        x: 1025,
        y: 770,
        stayAt: 0,
        frameWidth: 760,
        frameHeight: 1358,
        frameFrom: 0,
        frameTo: 5,
        frameRate: 10,
        scale: 0.48,
    },
};