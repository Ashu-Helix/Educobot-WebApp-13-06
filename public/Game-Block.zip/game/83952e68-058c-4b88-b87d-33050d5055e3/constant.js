// const GAME_CONSTANT = {
//   images: {    
//     carRushBg:"carRushBg",
//     carRushBg1:"carRushBg1",
//     carRushBg2:"carRushBg2",
//     carRushBg3:"carRushBg3",
//     fuelPump: "fuelPump"
//   },
//   spritesImages: {
//     fuelSprite: "fuelSprite",
//     leftArrowSprite: "leftArrowSprite",
//     rightArrowSprite: "rightArrowSprite",
//     upArrowSprite: "upArrowSprite",
//     downArrowSprite: "downArrowSprite",
//     shiftKey: "shiftKey"
//   },
//   physicsImages: {
//     lineDot: "lineDot",
//     carImg:"carImg",
//   }
// };
// const ERROR_MESSAGE = 'Error Message: <Write error message here>';
// const CORRECT_MESSAGE = 'Congratulation! Your reached at destination.';