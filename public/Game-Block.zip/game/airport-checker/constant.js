// const GAME_CONSTANT = {
//   images: {
//   BG: "gameAssets/BG.png",
//   machine: "gameAssets/machine.png",

//   bag1: "gameAssets/__Blue_Bag.png",
//   bag2: "gameAssets/__Green_Bag.png",
//   bag3: "gameAssets/__Meganta_Bag.png",
//   bag4: "gameAssets/__Red_Bag.png",
//   bag5: "gameAssets/__White_Bag.png",

//   bander: "gameAssets/br.png",
//   bandev: "gameAssets/bv.png",


//   line: "gameAssets/traitinter.png",

//   },
//   spritesImages: {
//    //bird: "Bird",
//   }
// };
// const ERROR_MESSAGE = '';
// const CORRECT_MESSAGE = '';