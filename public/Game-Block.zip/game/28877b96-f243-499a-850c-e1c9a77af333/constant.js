/* Developed by Marvsoft LLP */

// const GAME_CONSTANT = {
//     vehicleRushBg: "vehicleRushBg",
//     ambulance: "ambulance",
//     bus: "bus",
//     fireBrigade: "fireBrigade",
//     policeCar: "policeCar",
//     destination_0_0: "hospital",
//     destination_1_0: "policeStation",
//     destination_2_0: "fireStation",
//     destination_1_1: "busStand",
//     speechBubble: 'speechBubble'
// };
// const INCORRECT_MESSAGE = 'You have entered the incorrect coordinates for the building.';
// const CORRECT_MESSAGE = 'You have entered the correct coordinates for the building.';