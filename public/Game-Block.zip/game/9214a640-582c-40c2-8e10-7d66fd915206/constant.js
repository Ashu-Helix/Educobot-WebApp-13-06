/* Developed by Marvsoft LLP */

// const GAME_CONSTANT = {
//   saladBG: "saladBG",
// };
// const FRUITS = { banana: 'banana', blackBerry: 'blackBerry', blueBerry: 'blueBerry', grape: 'grape', strawberry: 'strawberry' };
// const CORRECT_MESSAGE = 'Well done, Perfect salad!';
// const ERROR_MESSAGE = 'Imperfect salad! Try again.';
// const MORE_THAN_AVAIL = 'Ohh...! You have selected more than available fruits.';