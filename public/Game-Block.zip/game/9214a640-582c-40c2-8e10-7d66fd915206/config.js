/* Developed by Marvsoft LLP */

// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;
// let depthMngr = 100;
// const POT_COORDINATE = { x1: 180, y1: 390, x2: 570, y2: 770 };
// const CORRECT_FRUIT_COUNT = 2;

// const BANANA = [
//     { x: 884, y: 666 },
//     { x: 946, y: 639 },
//     { x: 1038, y: 738 },
//     { x: 887, y: 738 },
//     { x: 951, y: 726 },
//     { x: 1020, y: 666 },
//     { x: 966, y: 805 }
// ];
// const GRAPE = [
//     { x: 1383, y: 684 },
//     { x: 1462, y: 686 },
//     { x: 1365, y: 753 },
//     { x: 1435, y: 743 },
//     { x: 1420, y: 805 },
//     { x: 1492, y: 763 }
// ];
// const BLACK_BERRY = [
//     { x: 1474, y: 284 },
//     { x: 1494, y: 344 },
//     { x: 1385, y: 374 }
// ];
// const BLUE_BERY = [
//     { x: 1393, y: 269 },
//     { x: 1425, y: 334 },
//     { x: 1474, y: 393 }
// ];
// const STRAWBERRY = [
//     { x: 909, y: 250 },
//     { x: 998, y: 220 },
//     { x: 894, y: 351 },
//     { x: 981, y: 312 },
//     { x: 1053, y: 317 },
//     { x: 993, y: 391 }
// ];