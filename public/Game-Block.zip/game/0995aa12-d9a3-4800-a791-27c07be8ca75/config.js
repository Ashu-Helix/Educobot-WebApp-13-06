// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;

// const staticImgPos = {
//     bearImg: { x: 630, y: 620 },
//     dogImg: { x: 630, y: 620 },
//     jokerImg: { x: 630, y: 620 },
//     lionImg: { x: 630, y: 620 },
//     monkeyImg: { x: 630, y: 620 },
//     clawMoveLR: { x: 400, y: 390 },
//     clawGlass1: { x: 630, y: 560 },
//     clawGlass3: { x: 435, y: 875 },
// }

// const spritesElement = {
//     clawMoveDown: { x: 450, y: 420, stayAt: 4, frameWidth: 176, frameHeight: 348, frameFrom: 0, frameTo: 4, frameRate: 4, repeat: 0 },
//     clawOC: { x: 450, y: 420, stayAt: 1, frameWidth: 195, frameHeight: 358, frameFrom: 0, frameTo: 1, frameRate: 5, repeat: 0 },
//     bearPick: { x: 430, y: 480, stayAt: 2, frameWidth: 165, frameHeight: 473, frameFrom: 0, frameTo: 2, frameRate: 5, repeat: 0 },
//     dogPick: { x: 570, y: 480, stayAt: 2, frameWidth: 147, frameHeight: 493, frameFrom: 0, frameTo: 2, frameRate: 5, repeat: 0 },
//     jokerPick: { x: 500, y: 480, stayAt: 2, frameWidth: 149, frameHeight: 477, frameFrom: 0, frameTo: 2, frameRate: 5, repeat: 0 },
//     lionPick: { x: 700, y: 480, stayAt: 2, frameWidth: 197, frameHeight: 468, frameFrom: 0, frameTo: 2, frameRate: 5, repeat: 0 },
//     monkeyPick: { x: 800, y: 480, stayAt: 2, frameWidth: 169, frameHeight: 445, frameFrom: 0, frameTo: 2, frameRate: 5, repeat: 0 },

//     bearDrop: { x: 430, y: 860, stayAt: 1, frameWidth: 141, frameHeight: 177, frameFrom: 0, frameTo: 1, frameRate: 4, repeat: 0 },
//     dogDrop: { x: 430, y: 860, stayAt: 1, frameWidth: 116, frameHeight: 192, frameFrom: 0, frameTo: 1, frameRate: 4, repeat: 0 },
//     jokerDrop: { x: 430, y: 860, stayAt: 1, frameWidth: 126, frameHeight: 179, frameFrom: 0, frameTo: 1, frameRate: 4, repeat: 0 },
//     lionDrop: { x: 430, y: 860, stayAt: 1, frameWidth: 146, frameHeight: 184, frameFrom: 0, frameTo: 1, frameRate: 4, repeat: 0 },
//     monkeyDrop: { x: 430, y: 860, stayAt: 1, frameWidth: 151, frameHeight: 194, frameFrom: 0, frameTo: 1, frameRate: 4, repeat: 0 }
// }

// const pickPoints = [
//     { x1: 430, y1: 540, x2: 470, y2: 720, name: 'bearPick' },
//     { x1: 485, y1: 540, x2: 555, y2: 720, name: 'jokerPick' },
//     { x1: 560, y1: 520, x2: 645, y2: 720, name: 'dogPick' },
//     { x1: 665, y1: 540, x2: 770, y2: 720, name: 'lionPick' },
//     { x1: 775, y1: 540, x2: 850, y2: 720, name: 'monkeyPick' }
// ]