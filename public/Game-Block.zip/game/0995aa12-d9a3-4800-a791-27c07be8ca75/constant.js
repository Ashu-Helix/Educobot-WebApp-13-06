// const GAME_CONSTANT = {
//   images: {
//     bgImg: "bgImg",
//     bearImg: "bearImg",
//     dogImg: "dogImg",
//     jokerImg: "jokerImg",
//     lionImg: "lionImg",
//     monkeyImg: "monkeyImg",
//     clawGlass1: "clawGlass1",
//     clawGlass2: "clawGlass2",
//     clawGlass3: "clawGlass3",
//     speechBubble:'speechBubble',
//     clawMoveLR: 'clawMoveLR'
//   },
//   spritesImages: {
//     clawMoveDown: "clawMoveDown",
//     clawOC: "clawOC",
//     bearPick: 'bearPick',
//     dogPick: 'dogPick',
//     monkeyPick: 'monkeyPick',
//     jokerPick: 'jokerPick',
//     lionPick: 'lionPick',
//     bearDrop: 'bearDrop',
//     dogDrop: 'dogDrop',
//     monkeyDrop: 'monkeyDrop',
//     jokerDrop: 'jokerDrop',
//     lionDrop: 'lionDrop'
//   }
// };

// const INCORRECT_MESSAGE = 'Wrong coordinates.';
// const CORRECT_MESSAGE = 'Toy is picked up.';
// const ALL_TOY_MESSAGE = 'All toys are picked up.';