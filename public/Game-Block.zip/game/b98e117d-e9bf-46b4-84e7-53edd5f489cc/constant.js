/* Developed by Marvsoft LLP */

// const GAME_CONSTANT = {
//   images: {
//     magicianBG: 'magicianBG',
//     speechBubble:'speechBubble'
//   },
//   spritesImages: {
//     appleSprite: 'appleSprite',
//     bunnySprite: 'bunnySprite',
//     confettiDownward: 'confettiDownward',
//     magicWandUpward: 'magicWandUpward'
//   }
// };