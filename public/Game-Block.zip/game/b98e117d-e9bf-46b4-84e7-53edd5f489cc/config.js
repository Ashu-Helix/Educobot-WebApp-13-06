// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;

// const magicElement = {
//     bunnySprite: { x: 980, y: 340, stay: 15, frameWidth: 233, frameHeight: 382, frameFrom: 0, frameTo: 15, frameRate: 8 },
//     appleSprite: { x: 960, y: 550, stay: 15, frameWidth: 1920, frameHeight: 1080, frameFrom: 0, frameTo: 7, frameRate: 6 },
//     confettiDownward: { x: 960, y: 300, stay: 15, frameWidth: 498, frameHeight: 467, frameFrom: 0, frameTo: 8, frameRate: 5 },
//     magicWandUpward: { x: 1300, y: 500, stay: 15, frameWidth: 324, frameHeight: 321, frameFrom: 0, frameTo: 107, frameRate: 20 }
// }

// const dialogue = ['Welcome!', 'Let’s start the magic show', 'Tada', 'Next Magic', 'Next magic', 'Last magic of the day', 'Thankyou everyone'];