/* Developed by Marvsoft LLP */

// const GAME_CONSTANT = {
//   images: {
//     gardenBg: "gardenBg",
//     speechBubble:'speechBubble'
//   },
//   spritesImages: {
//     meterSprite: "meterSprite",
//     waterCaneSprite: "waterCaneSprite",
//   },
// };
// const INCORRECT_PLANT_FOR_WATER = "You have selected wrong plant for watering.";
// const INCORRECT_PLANT_TYPE = "You have selected wrong plant type.";
// const INCORRECT_MESSAGE = "You have selected wrong coordinates.";
// const INCORRECT_DOUBLE_WATERING = "Double watering a ";
// const OVER_WATERED = "Over watered ";
// const UNDER_WATERED  = "Under watered ";
// const CORRECT_MESSAGE = "Correct Message: <Write correct message here>";