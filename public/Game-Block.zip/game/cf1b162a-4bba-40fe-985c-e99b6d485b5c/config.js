// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;

// const magicElement = {
//     meterSprite: { x: 545, y: 400, stay: 1, frameWidth: 212, frameHeight: 169, frameFrom: 0, frameTo: 24, frameRate: 6 },

//     meter_tree: { x: 545, y: 400, frameFrom: 0, frameTo: 3, frameRate: 3 },
//     meter_shrub: { x: 1010, y: 400, frameFrom: 0, frameTo: 3, frameRate: 6 },
//     meter_grass: { x: 1545, y: 400, frameFrom: 0, frameTo: 3, frameRate: 6 },

//     meter_normal: { frameFrom: 3, frameTo: 5, frameRate: 6 },
//     meter_over: { frameFrom: 3, frameTo: 14, frameRate: 6 },

//     waterCaneSprite: { x: 445, y: 600, stay: 1, frameWidth: 300, frameHeight: 363, frameFrom: 0, frameTo: 49, frameRate: 6 },

//     cane_tree: { x: 445, y: 700, frameFrom: 0, frameTo: 24, frameRate: 6, time: 10 },
//     cane_shrub: { x: 1010, y: 700, frameFrom: 0, frameTo: 24, frameRate: 6, time: 8 },
//     cane_grass: { x: 1545, y: 700, frameFrom: 0, frameTo: 24, frameRate: 6, time: 15 },
// };

// const hitPoints = {
//     tree: [
//         { x1: 0, y1: 220, x2: 480, y2: 500 },
//         { x1: 0, y1: 800, x2: 450, y2: 950 },
//         { x1: 150, y1: 520, x2: 190, y2: 800 }
//     ],
//     shrub: [{ x1: 640, y1: 740, x2: 1150, y2: 920 }],
//     grass: [{ x1: 1230, y1: 720, x2: 1900, y2: 910 }]
// };