// const GAME_CONSTANT = {
//     images: {
//         wondersOfTheWorldBg: "wondersOfTheWorldBg",
//         tajMahal: "tajMahal",
//         statueOfLib: "statueOfLib",
//         lotus: "lotus",
//         london: "london",
//         egypt: "egypt",
//         brazil: "brazil",
//         dubai: "dubai",
//         france: "france",
//         hungry: "hungry",
//         india: "india",
//         italy: "italy",
//         uk: "uk",
//         egyptZoom: "egyptZoom",
//         speechBubble: 'speechBubble'
//     },
// };

// const MONOMENTS = {
//     tajMahal: "tajMahal",
//     statueOfLib: "statueOfLib",
//     lotus: "lotus",
//     london: "london",
//     egypt: "egypt",
//     brazil: "brazil",
// };

// const COUNTRIES = {
//     India: "India",
//     UnitedStates: "UnitedStates",
//     Australia: "Australia",
//     London: "London",
//     Egypt: "Egypt",
//     Brazil: "Brazil",
// };

// const MAP = {
//     dubai: "dubai",
//     france: "france",
//     hungry: "hungry",
//     india: "india",
//     italy: "italy",
//     uk: "uk",
//     egyptZoom: "egyptZoom",
// };

// const INCORRECT_COUNTRY = "You have selected incorrect country  ";
// const INCORRECT_COUNTRY_CORDS = "You have selected incorrect coordinates for country  ";
// const INCORRECT_MESSAGE = "You have selected wrong monument for ";
// const CORRECT_MESSAGE = "You have selected correct monument for ";