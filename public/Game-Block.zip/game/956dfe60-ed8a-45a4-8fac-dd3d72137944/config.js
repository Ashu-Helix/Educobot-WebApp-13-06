// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;

// const monumentsLocation = {
//     tajMahal_India: { x: 1269, y: 638, duration: 2 },
//     statueOfLib_UnitedStates: { x: 441, y: 551, duration: 0.7 },
//     lotus_Australia: { x: 1518, y: 865, duration: 2 },
//     london_London: { x: 978, y: 373, duration: 1.5 },
//     egypt_Egypt: { x: 1033, y: 623, duration: 1.5 },
//     brazil_Brazil: { x: 666, y: 800, duration: 1 },
// };

// const monumentsInitPosition = {
//     tajMahal: { x: 180, y: 570 },
//     statueOfLib: { x: 75, y: 750 },
//     lotus: { x: 250, y: 750 },
//     london: { x: 85, y: 950 },
//     egypt: { x: 260, y: 950 },
//     brazil: { x: 400, y: 950 },
// };

// const mapPosition = {
//     dubai: { x: 1150, y: 630, scaleMin: 0.05, scaleMax: 0.5 },
//     france: { x: 914, y: 515, scaleMin: 0.05, scaleMax: 0.5 },
//     hungry: { x: 995, y: 501, scaleMin: 0.05, scaleMax: 0.5 },
//     india: { x: 1280, y: 655, scaleMin: 0.15, scaleMax: 0.5 },
//     italy: { x: 951, y: 517, scaleMin: 0.05, scaleMax: 0.5 },
//     uk: { x: 894, y: 451, scaleMin: 0.05, scaleMax: 0.5 },
//     egyptZoom: { x: 1040, y: 625, scaleMin: 0.05, scaleMax: 0.8 }
// };

// const hitPoints = {
//     India: { x1: 1234, y1: 564, x2: 1340, y2: 712 },
//     UnitedStates: { x1: 340, y1: 493, x2: 595, y2: 617 },
//     Australia: { x1: 1423, y1: 812, x2: 1607, y2: 931 },
//     London: { x1: 870, y1: 425, x2: 920, y2: 480 },
//     Egypt: { x1: 1021, y1: 599, x2: 1068, y2: 646 },
//     Brazil: { x1: 589, y1: 735, x2: 719, y2: 895 }
// };