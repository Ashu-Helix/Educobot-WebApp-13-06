// const GAME_CONSTANT = {
//   images: {
//   BG: "gameAssets/Background.png",
//   Button_1: "gameAssets/Button_1.png",
//   Button_2: "gameAssets/Button_2.png",
//   Button_3: "gameAssets/Button_3.png",

//   Normal_left:"gameAssets/Normal_left.png",
//   Paper_left:"gameAssets/Paper_left.png",
//   Scissor_left:"gameAssets/Scissor_left.png",
//   Stone_left:"gameAssets/Stone_left.png",

//   Normal_right:"gameAssets/Normal_right.png",
//   Paper_right:"gameAssets/Paper_right.png",
//   Scissor_right:"gameAssets/Scissor_right.png",
//   Stone_right:"gameAssets/Stone_right.png"

//   },
//   spritesImages: {
//   }
// };
// const ERROR_MESSAGE = '';
// const CORRECT_MESSAGE = '';