// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 1;