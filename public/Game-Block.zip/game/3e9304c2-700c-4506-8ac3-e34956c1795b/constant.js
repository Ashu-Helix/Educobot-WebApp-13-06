// const GAME_CONSTANT = {
//   images: {
//     farmBg: "farmBg",
//     farmGirl: "farmGirl",
//     speechBubble: "speechBubble"
//   },
//   spritesImages: {
//     chickenSprite: "chickenSprite",
//     henSprite: "henSprite",
//     cowSprite: "cowSprite",
//     pigSprite: "pigSprite",
//     sheepSprite: "sheepSprite"
//   },
//   sounds:{
//     cowSound: 'cowSound',
//     henSound: 'henSound',
//     sheepSound: 'sheepSound',
//     pigSound: 'pigSound'
//   }
// };
// const INCORRECT_MESSAGE = 'Incorrect Message: <Write error message here>';
// const CORRECT_MESSAGE = 'Correct Message: <Write correct message here>';
// const END_MESSAGE = 'You are not add the End Block in blockly.';