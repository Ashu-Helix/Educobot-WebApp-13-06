// let _gameThis = null;
// const baseURL = "assets";
// const gameWidth = 1920;
// const gameHeight = 1080;
// const gameScale = 0.5;

// const animalNameArr = ['cow','sheep','hen','chicken','pig'];

// const spritesElement = {
//     cowSprite: { x: 615, y: 745, stayAt: 4, frameWidth: 307, frameHeight: 242, frameFrom: 0, frameTo: 4, frameRate: 10, scale: 1.5 },
//     sheepSprite: { x: 940, y: 870, stayAt: 12, frameWidth: 395, frameHeight: 336, frameFrom: 0, frameTo: 12, frameRate: 5, scale: 0.8 },
//     henSprite: { x: 960, y: 620, stayAt: 13, frameWidth: 545, frameHeight: 336, frameFrom: 0, frameTo: 13, frameRate: 10, scale: 0.8 },
//     chickenSprite: { x: 960, y: 620, stayAt: 84, frameWidth: 172, frameHeight: 107, frameFrom: 0, frameTo: 84, frameRate: 20, scale: 2.5 },
//     pigSprite: { x: 300, y: 700, stayAt: 13, frameWidth: 395, frameHeight: 336, frameFrom: 0, frameTo: 13, frameRate: 10, scale: 0.8 }
// }