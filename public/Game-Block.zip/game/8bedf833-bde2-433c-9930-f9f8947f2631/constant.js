/* Developed by Marvsoft LLP */

// const GAME_CONSTANT = {
//     masterChefBg: "masterChefBg",
//     plate0: 'plate0',
//     plate1: 'plate1',
//     plate2: 'plate2',
//     pizzaSlice0: 'pizzaSlice0',
//     pizzaSlice1: 'pizzaSlice1',
//     pizzaSlice2: 'pizzaSlice2',
//     pizzaSlice3: 'pizzaSlice3',
//     pizzaSlice4: 'pizzaSlice4',
//     pizzaSlice5: 'pizzaSlice5',
//     pizzaSlice6: 'pizzaSlice6',
// };
// const CORRECT_MESSAGE = 'Congrats...! You have served the correct pizza slices in both plates.';
// const ERROR_MESSAGE = 'Ohh...! You have not served the correct pizza slices.';